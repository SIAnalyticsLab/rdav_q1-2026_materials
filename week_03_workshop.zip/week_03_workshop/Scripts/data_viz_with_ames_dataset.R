############################################################
# WORKSHOP: DATA VISUALISATION WITH AMES HOUSING DATASET
# Comprehensive R Script (Clean, Structured, Executable)
############################################################

# =========================
# Part 1: Exploratory Data Visualization
# =========================

# Consider the following questions about the Ames housing dataset. For each question, 
# create a simple plot that addresses the question. Then make a comment on interpreting the plot. 
# Your plots do not have to be elegant; focus on selecting the appropriate type of visualization for each question.

# Variable Documentation (you can use Ctrl+F to search through):
  
#  1. https://vincentarelbundock.github.io/Rdatasets/doc/openintro/ames.html
#  2. https://jse.amstat.org/v19n3/decock/DataDocumentation.txt
First, import the necessary libraries and read in the dataset:
  
  
# Load required libraries
library(tidyverse)
library(plotly)

# Set display options
options(dplyr.width = Inf)

# Load dataset
ames <- read_csv("https://raw.githubusercontent.com/SIAnalyticsLab/pdav_q1-2026_materials/refs/heads/main/week_03_workshop/data/ames.csv")

# Clean column names 
ames <- ames %>%
  rename_with(~ gsub("\\.", "_", .x))

# Preview data
head(ames)
glimpse(ames)

# =============================================================
# PART 1: EXPLORATORY DATA VISUALISATION (Group Work)
# =============================================================

# ---------------------------------------------------------
# 1.1 What is the relationship between the size of the house and the price?
# - Variables: `Lot_Area`, `price`
# ---------------------------------------------------------

# Create a plot of Lot_Area vs. price
# ANSWER HERE

# Interpretation:
# [ONE SENTENCE ANSWER TO THE QUESTION HERE (What is the relationship between the size of the house and the price?)]


# ---------------------------------------------------------
# 1.2. Are houses originally built earlier in the 1900s more expensive than those built later in the century?
# Variables: Year_Built, price
# ---------------------------------------------------------

# Create a plot to explore the relationship between Year_Built and price
# ANSWER HERE

# Interpretation:
# [ONE SENTENCE ANSWER TO THE QUESTION HERE]


# ---------------------------------------------------------
# 1.3 What is the most common type of primary exterior material?
# Variable: Exterior_1st
# ---------------------------------------------------------

# Create a plot to show the distribution of Exterior_1st
# ANSWER HERE

# Interpretation:
# [ONE SENTENCE ANSWER TO THE QUESTION HERE]


# ---------------------------------------------------------
# 1.4 Which neighborhood has the highest proportion of Single-family Detached homes?
# Variables: Neighborhood, Bldg_Type
# ---------------------------------------------------------

# Create a plot to show the proportions of Single-family Detached homes across neighborhoods
# ANSWER HERE

# Interpretation:
# [ONE SENTENCE ANSWER TO THE QUESTION HERE]


# ====================================================
# PART 2: MULTIVARIATE VISUALISATION (Individual Task)
# ====================================================

# For this section, you will work individually. Your chosen plot should not be the same as those of your group members.

# Look through the dataset and decide on three variables that could be visualized on a single plot (or on a faceted plot).

# Create a multivariate plot that visualizes these variables.

# Create your multivariate plot
# ANSWER HERE

# Interpretation:
# Write a brief interpretation of any findings you can deduce from the plot.



# ===========================================================
# PART 3: FIXING ERRORS & STACKED BAR CHART (Individual Task)
# ===========================================================

# The following code chunk attempts to create a stacked bar chart of central air conditioning by heating quality, but it contains several syntax errors.

# Instructions:
#  a. Identify and correct the syntax errors in the script so that it runs correctly.
#  b. Run the corrected code and observe the output.
#  c. Interpret the resulting plot.

# First we use the replace method to change values according to the mapping
# We have not taught this yet, but you should be able to read and understand the gist of it
# Define a list to map the values (replace with their full names)

# ---------------------------------------------------------
# First check the two columns in the data set to see what it looks like
# ---------------------------------------------------------
ames %>% select(Heating_QC,Central_Air )

# ---------------------------------------------------------
# Dictionary for Heating Quality and Condition labels
# ---------------------------------------------------------

heating_qc_labels <- c(
  "Ex" = "Excellent",
  "Gd" = "Good"
  "TA" = "Average/Typical",
  "Fa" = "Fair",
  "Po" = "Poor"
)
# ---------------------------------------------------------
# Dictionary for Central Air Conditioning labels
# ---------------------------------------------------------

central_air_labels <- c(
  "Y" = "Yes",
  "N" = "No"
)

# ---------------------------------------------------------
# Apply the mapping to the DataFrame
# ---------------------------------------------------------

ames <- ames %>%
  mutate(
    Heating_QC_full = recode(Heating_QC, !!!heating_qc_labels),
    Central_Air_full = recode(Central_Air, !!!central_air_labels)
  )

# ---------------------------------------------------------
# Prepare Aggregated Data 
# ---------------------------------------------------------

plot_data <- ames %>%
  count(Central_Air_full, Heating_QC_full) %>%
  group_by(Central_Air_full) %>%
  mutate(percent = n / sum(n)) %>%
  ungroup()

# Ensure correct ordering
plot_data$Heating_QC_full <- factor(
  plot_data$Heating_QC_full,
  levels = c("Poor", "Fair", "Average/Typical", "Good", "Excellent")
)

# ---------------------------------------------------------
# Create Stacked Bar Chart (Percent) using plot_ly
# ---------------------------------------------------------

plot_ly(
  data = PLOT_DATA,
  x = ~Central_Air_full,
  y = ~percent,
  color = ~Heating_QC_full,
  colors = c("#d9534f", "#e39283", "#e8c590", "#a3c9a8", "#5cb85c"),
  type = "bar"
) %>%
  layout(
    barmode = "stack",
    title = list(text = "Central Air Conditioning by Heating Quality in Ames Housing"),
    xaxis = list(title = ""),
    yaxis = list(
      title = "Percentage",
      tickformat = ".0%"
    ),
    legend = list(title = list(text = "Heating Quality"))
  )

# Interpretation:
# Homes with higher heating quality are more likely to have central air,
# indicating a clustering of higher overall housing standards.

############################################################
# END OF SCRIPT
############################################################