# =================================================================================
# SI ANALYTICS WORKSHOP
# Data Structures & Visualization of Financial Independence Survey with Plotly in R
# =================================================================================

## NAME: [Firstname Lastname]

#In this workshop, you'll apply your knowledge of R data structures, debugging, and data visualization.

# There are four sections. The first two sections should be completed together in your group (with one person screen sharing). The last two sections should be completed individually.

# ------------------------------------------------------------------------------
# WORKSHOP OBJECTIVES
# ------------------------------------------------------------------------------
# By the end of this session, you will be able to:
# - Understand and identify core R data structures
# - Apply tidyverse workflows for data manipulation
# - Build and customize interactive visualizations using plotly
# - Debug and correct common coding errors
# - Interpret visual outputs for decision-making

# ------------------------------------------------------------------------------
# SETUP
# ------------------------------------------------------------------------------
if(!require(pacman)) install.packages("pacman")
pacman::p_load(tidyverse, plotly, readr)

# ================================================================================
# PART 1: DATA STRUCTURES + DEBUGGING
# ================================================================================

# Create vectors
ages <- c(28, 34, 29, 45, 23, 38, 31, 40, 27, 50)
names <- c("Ally", "Bob", "Char", "Dav", "Eve", "Fran",
           "Grace", "Han", "Ivy", "Jo")

# Create tibble (preferred over data.frame)
survey_df <- tibble(
  Age = ages,
  Name = names
)

# Inspect data
glimpse(survey_df)
head(survey_df)

# ------------------------------------------------------------
# EXERCISE 1: DATA STRUCTURES
# ------------------------------------------------------------

# Answer the following:

# - What type of object is `ages`?:
# - What data type is each element in `ages`?:
# - What type of data structure is `names`?: 
# - What data type is each element in `names`?:
# - What type of data structure is `survey_df`?: 
# - Why is tibble preferred over data.frame?:


# ------------------------------------------------------------
# EXERCISE 2: DEBUGGING + VISUALIZATION
# ------------------------------------------------------------

# TASK:
# The chunk below attempts to create a histogram of respondent ages in survey_df but contains several syntax errors:

# Step 1: Start minimal
plot_ly(survey_df, x = Age, type = "histogram')

# Step 2: Enhance progressively
plot_ly(
  survey_df
  x = Age,
  type = "histogram",
  marker = list(color = "#3366CC")
) %>%
  layout(
    title = "Age Distribution of Respondents",
    xaxis = list(title = "Respondent Age"),
    yaxis = list(title = "Number of Respondents")
  )

# ------------------------------------------------------------
  # QUESTION
# ------------------------------------------------------------

# a. Identify and correct the syntax errors in the script so that it runs correctly.

# b. Run the corrected code and observe the output.

# c. Interpret the histogram. (Describe the distribution of ages in the sample.)


# ------------------------------------------------------------
# INTERPRETATION
# ------------------------------------------------------------

# Describe:
# - Shape of the distribution (symmetric, skewed?)
# - Range of ages
# - Any visible clustering or gaps


# ============================================================
# PART 2: REPRODUCING REAL-WORLD VISUALS
# ============================================================
# For this section you will be recreating a plot from a survey dataset of Reddit users in the r/financialindependence subreddit (an online community).

# They are part of a movement of people who hope to save enough money to become financially independent early in life, so they can focus on other goals later.

# (As a side note, the in-demand data and tech skills you are learning in this program could be useful for your own financial goals!)

#Steps
# 1. Visit this [GitHub Pages link] ((https://sianalyticslab.github.io/pdav_q1-2026_materials/week_02_workshop/pdav_week_02_workshop_reddit_finance_plots)) to view the plots we want you to reproduce. 
# It may take a few seconds for them to load.

# 2. Import the source dataset into Google Colab with the code below:

# Load dataset
url <- "https://raw.githubusercontent.com/SIAnalyticsLab/pdav_q1-2026_materials/main/week_02_workshop/data/reddit_finance.csv"

reddit_fi <- read_csv(url)

# Inspect
view(reddit_fi)

# ------------------------------------------------------------
# EXERCISE: INDUSTRY DISTRIBUTION
# ------------------------------------------------------------

# Your code

# ------------------------------------------------------------
# OPTIONAL: TREEMAP (ADVANCED)
# ------------------------------------------------------------

# Your code

# ============================================================
# PART 3: UNIVARIATE ANALYSIS (INDIVIDUAL EXPLORATION)
# ============================================================
# For this section, you will work individually. Your chosen plots should not be the same as those of your group members.

# a. Individually, select two other interesting columns from the reddit_fi dataset. This should include one categorical variable and one numeric/quantitative variable.

# b. For each selected column, create an elegant univariate plot to visualize its distribution.

# TASK:
# Select:
# - One categorical variable
# - One numeric variable

# ------------------------------------------------------------
# EXAMPLE: CATEGORICAL (BAR)
# ------------------------------------------------------------
# For categorical variables, consider using bar charts, pie charts, or treemaps.
# For quantitative variables, consider using histograms, box plots, or violin plots.
# c. Customize your plots with:

# Appropriate titles and axis labels.
# Customized colors or themes.
# Any additional annotations or features that enhance the visualization.
# d. Write a brief interpretation for each plot, explaining any interesting insights or observations.

# START YOUR ANSWERS HERE:



# ------------------------------------------------------------
# EXAMPLE: NUMERIC (HISTOGRAM)
# ------------------------------------------------------------

# Your code




# ============================================================
# PART 4: Bivariate Plots Optional Challenge (Ungraded)
# ============================================================
# Although we haven't covered bivariate or multivariate plots yet, you can experiment with creating one informative bivariate or multivariate plot using the plotly express functions.

#For example, create a scatter plot, or a stacked bar plot. Feel free to consult the function documentation, Google or ChatGPT.

# Example: Scatter Plot

# Your code

# ------------------------------------------------------------
# REFLECTION
# ------------------------------------------------------------

# - What relationships do you observe?
# - Which industries cluster together?
# - Are there outliers?


# ============================================================
# KEY TAKEAWAYS
# ============================================================

# - Tidyverse enables clean, readable data workflows
# - Plotly builds visualizations step-by-step
# - Always start simple, then enhance
# - Good visualization = clarity + insight

# ============================================================
# END OF WORKSHOP
# ============================================================
  